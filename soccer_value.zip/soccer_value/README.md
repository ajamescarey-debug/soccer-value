# Soccer Value v1

A bivariate-Poisson goal model for mid-tier European and non-European soccer leagues. Identifies bets where the model probability exceeds the de-vigged book probability by a configurable threshold. Logs every flagged bet, tracks closing-line value (CLV), and operates in paper-trading mode by default.

## Why this exists

Two reasons:

1. To find out, with real data and an honest CLV track record, whether a one-person Poisson xG model has any edge against the modern market. We genuinely don't know — we'll know in a few hundred bets.
2. To replace gut-feel betting with a system that has a kill switch.

## Design rules

- **Paper-trade first.** No real money until at least 500 logged bets and positive CLV.
- **CLV is the metric.** P&L over small samples is noise. CLV over 100+ bets is signal.
- **Kill switch is non-negotiable.** If after 500 bets average CLV is negative, the model doesn't work and we stop.
- **No multis in v1.** Singles only. The 2-leg correlated layer (v2) sits on top after v1 has a track record.
- **No top-5 leagues.** EPL, La Liga, Bundesliga, Serie A, Ligue 1 are excluded — the lines are too sharp.

## Project structure

```
src/
  config.py       Knobs: leagues, edge threshold, mode (PAPER/LIVE)
  model.py        Bivariate Poisson — the analytical core
  devig.py        Strip bookmaker margin to get true implied probabilities
  value.py        Compare model to book, flag value bets
  clv.py          Track closing-line value (the only edge metric we trust)
  data.py         Odds API + xG fetching (cached)
  run_daily.py    Pipeline entry point
  tests.py        End-to-end tests on synthetic data
results/
  picks.json      Today's flagged bets (consumed by the dashboard)
  clv.json        Rolling log of every taken bet + closing odds + CLV
docs/
  index.html      GitHub Pages dashboard
.github/workflows/
  daily.yml       Cron 09:00 and 21:00 UTC
```

## Setup

1. Push to a fresh GitHub repo.
2. In repo settings, add a secret: `ODDS_API_KEY` (your existing The Odds API key).
3. Enable GitHub Pages from the `docs/` folder.
4. Wire up the FBref/Understat scraper inside `src/data.fetch_team_strengths`. The shape of `TeamStrength` is fully specified — once that returns real data the rest works.
5. Wire up the Odds API call inside `src/data.fetch_odds_for_league`. Same — the shape of `FixtureOdds` is fully specified.

## Running locally

```bash
python -m src.tests        # unit tests, runs offline
python -m src.run_daily    # full pipeline (needs ODDS_API_KEY env var)
```

## Going live

Don't, until:
- At least 500 logged bets (probably 2-3 months of running)
- Average CLV is meaningfully positive (target +1.5% or better)
- The kill switch hasn't fired

When you do go live, flip `LIVE_MODE = True` in `config.py`. Stakes will switch from flat $100 units to quarter-Kelly sizing automatically.

## What this is not

- Not a get-rich system. If it works, expected ROI is 2-5% on turnover.
- Not a winner-picker. Half the bets we flag will lose. The math comes out positive only over hundreds of bets, if at all.
- Not a substitute for understanding what you're betting on. If a bet looks weird, override the model.

## What we're actually testing

The hypothesis: in the listed leagues, in the listed markets (totals + BTTS), there exist enough mispriced books that a one-person xG-based Poisson model can systematically take prices better than the closing line.

If the hypothesis is true, CLV will be positive. If false, CLV will be near zero or negative, and we will have learned something useful for the cost of running GitHub Actions.
