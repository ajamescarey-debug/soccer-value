"""
Value detection.

Given a fixture, our model's market probabilities, and the bookmaker's
quoted odds across multiple books, find the bets where our edge exceeds
the threshold.

Key concepts:
  - Edge = model_prob - devigged_book_prob. We want this positive.
  - "Best price" = the highest decimal odds available across books for
    the side we want to back. We bet whoever's lazy.
  - Expected Value (EV) per unit staked = (model_prob * (odds - 1)) - (1 - model_prob)

The value threshold (config.MIN_EDGE) is in probability terms, not EV
terms. A 4% probability edge at $2.00 odds is roughly an 8% EV bet.
"""

from dataclasses import dataclass
from typing import Dict, List, Optional

from . import config
from . import devig


@dataclass
class ValueBet:
    """A flagged value bet, ready for logging or placement."""
    fixture: str               # "Team A vs Team B"
    league: str
    kickoff: str               # ISO timestamp
    market: str                # e.g. "over_2_5"
    selection: str             # human-readable, e.g. "Over 2.5 goals"
    best_odds: float
    best_book: str
    model_prob: float
    devigged_prob: float
    edge: float                # model_prob - devigged_prob
    expected_value: float      # EV per $1 staked
    stake: float               # in $


def _ev_per_unit(prob: float, odds: float) -> float:
    """Expected return per $1 staked. 0.05 = 5% EV."""
    return prob * (odds - 1) - (1 - prob)


def _kelly_stake(prob: float, odds: float, bankroll: float) -> float:
    """
    Fractional Kelly stake. Full Kelly is f = (bp - q) / b where
    b = odds - 1, p = win prob, q = lose prob.

    We multiply by config.KELLY_FRACTION (0.25 by default) because
    full Kelly is too aggressive in the presence of model uncertainty.
    """
    b = odds - 1
    q = 1 - prob
    f = (b * prob - q) / b
    if f <= 0:
        return 0.0
    return bankroll * f * config.KELLY_FRACTION


def find_value_bets(
    fixture_label: str,
    league: str,
    kickoff: str,
    model_probs: Dict[str, float],
    book_odds: Dict[str, Dict[str, Dict[str, float]]],
    bankroll: float = 10000.0,
) -> List[ValueBet]:
    """
    For each market we model, check every book for a price that beats
    our model probability by config.MIN_EDGE.

    `book_odds` shape:
      {
        "totals_2_5": {
          "Pinnacle":   {"over": 1.85, "under": 1.95},
          "Sportsbet":  {"over": 1.80, "under": 2.00},
          ...
        },
        "btts": {
          "Pinnacle":   {"yes": 1.72, "no": 2.10},
          ...
        }
      }
    """
    value_bets: List[ValueBet] = []

    market_map = [
        ("totals_1_5", "over",  "over_1_5",  "under_1_5", "Over 1.5 goals"),
        ("totals_1_5", "under", "under_1_5", "over_1_5",  "Under 1.5 goals"),
        ("totals_2_5", "over",  "over_2_5",  "under_2_5", "Over 2.5 goals"),
        ("totals_2_5", "under", "under_2_5", "over_2_5",  "Under 2.5 goals"),
        ("totals_3_5", "over",  "over_3_5",  "under_3_5", "Over 3.5 goals"),
        ("totals_3_5", "under", "under_3_5", "over_3_5",  "Under 3.5 goals"),
        ("btts",       "yes",   "btts_yes",  "btts_no",   "Both Teams to Score - Yes"),
        ("btts",       "no",    "btts_no",   "btts_yes",  "Both Teams to Score - No"),
    ]

    for book_market, side, model_key, opp_key, label in market_map:
        if book_market not in book_odds:
            continue

        # Find the best (highest) odds across books for this side
        best_odds = 0.0
        best_book: Optional[str] = None
        best_pair: Optional[Dict[str, float]] = None

        for book_name, prices in book_odds[book_market].items():
            if side not in prices:
                continue
            opposite_side = "under" if side == "over" else "yes" if side == "no" else "no" if side == "yes" else "over"
            if opposite_side not in prices:
                continue

            if prices[side] > best_odds:
                best_odds = prices[side]
                best_book = book_name
                best_pair = prices

        if not best_book or best_odds < config.MIN_ODDS or best_odds > config.MAX_ODDS:
            continue

        # De-vig using the same book's two-sided market
        opposite_side = "under" if side == "over" else ("no" if side == "yes" else ("yes" if side == "no" else "over"))
        try:
            devigged = devig.devig_two_way(best_pair[side], best_pair[opposite_side])
        except (ValueError, KeyError):
            continue

        devigged_prob = devigged["yes"] if side in ("over", "yes") else devigged["no"]
        model_prob = model_probs[model_key]
        edge = model_prob - devigged_prob

        if edge < config.MIN_EDGE:
            continue

        ev = _ev_per_unit(model_prob, best_odds)
        if config.LIVE_MODE:
            stake = _kelly_stake(model_prob, best_odds, bankroll)
        else:
            stake = config.UNIT_SIZE

        value_bets.append(ValueBet(
            fixture=fixture_label,
            league=league,
            kickoff=kickoff,
            market=model_key,
            selection=label,
            best_odds=round(best_odds, 3),
            best_book=best_book,
            model_prob=round(model_prob, 4),
            devigged_prob=round(devigged_prob, 4),
            edge=round(edge, 4),
            expected_value=round(ev, 4),
            stake=round(stake, 2),
        ))

    return value_bets
